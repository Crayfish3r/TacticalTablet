gamemode spectator @s
