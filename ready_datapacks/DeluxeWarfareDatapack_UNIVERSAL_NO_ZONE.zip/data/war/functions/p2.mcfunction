﻿# Фаза 2. Плавное сужение 360 -> 260.

scoreboard players set #time timer 210

title @a title {"text":"ФАЗА 2","color":"yellow","bold":true}
title @a subtitle {"text":"Зона плавно сужается до 260 блоков","color":"gold"}
tellraw @a {"text":"[WAR] Фаза 2: зона плавно сужается до 260 блоков за 150 секунд.","color":"yellow"}
playsound minecraft:block.note_block.bell master @a ~ ~ ~ 1 1

