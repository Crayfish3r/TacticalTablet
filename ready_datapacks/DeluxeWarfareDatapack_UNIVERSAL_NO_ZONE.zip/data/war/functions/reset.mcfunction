# Полный сброс раунда. После сброса Forge-мод запустит новый матч, когда будет достаточно игроков.

scoreboard players set #state gameState 0
scoreboard players set #phase phase 1
scoreboard players set #time timer 0
scoreboard players set #alive timer 0
scoreboard players set #restart timer 15
ttrespawns enable

gamemode survival @a[tag=war.playing,gamemode=spectator]
tag @a remove war.playing
tag @a add in_lobby

title @a clear
tellraw @a {"text":"[WAR] Раунд сброшен. Игроки возвращаются в lobby:lobby модом. Новый раунд запустится автоматически, когда будет достаточно игроков.","color":"yellow"}
