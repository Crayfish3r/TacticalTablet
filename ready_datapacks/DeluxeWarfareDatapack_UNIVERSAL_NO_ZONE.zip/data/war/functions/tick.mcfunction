# Battle Royale loop is called once per second by the Forge mod.
# This function is kept for manual compatibility: /function war:tick

execute if score #state gameState matches 1 run function war:game_tick
