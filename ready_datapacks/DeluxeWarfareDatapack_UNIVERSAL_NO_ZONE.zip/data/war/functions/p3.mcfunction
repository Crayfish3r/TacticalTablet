﻿# Фаза 3. Плавное сужение 260 -> 180.

scoreboard players set #time timer 210

title @a title {"text":"ФАЗА 3","color":"gold","bold":true}
title @a subtitle {"text":"Зона плавно сужается до 180 блоков","color":"yellow"}
tellraw @a {"text":"[WAR] Фаза 3: зона плавно сужается до 180 блоков за 150 секунд.","color":"gold"}
playsound minecraft:block.note_block.bell master @a ~ ~ ~ 1 1.1

