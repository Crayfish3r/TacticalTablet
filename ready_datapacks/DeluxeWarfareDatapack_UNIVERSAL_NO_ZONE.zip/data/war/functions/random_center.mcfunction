# Zone center is controlled by the Forge mod from tacticaltablet_zone.json.
# Kept as a no-op for compatibility with old manual commands.
