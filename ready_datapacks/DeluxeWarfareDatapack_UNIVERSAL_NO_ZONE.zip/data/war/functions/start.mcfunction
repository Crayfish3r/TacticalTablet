# Совместимость со старой командой /function war:start.
# Теперь просто запускает полноценный матч.

function war:start_game
