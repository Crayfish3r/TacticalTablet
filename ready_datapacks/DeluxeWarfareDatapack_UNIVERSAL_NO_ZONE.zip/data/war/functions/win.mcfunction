# Оставлено для совместимости. Основное завершение матча делает Forge-мод.

scoreboard players set #state gameState 0
scoreboard players set #restart timer 15

title @a title {"text":"ПОБЕДА!","color":"gold","bold":true}
title @a subtitle [{"text":"Победитель: ","color":"yellow"},{"selector":"@s","color":"gold","bold":true}]
tellraw @a [{"text":"[WAR] Победитель: ","color":"gold"},{"selector":"@s","color":"yellow","bold":true}]
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 1 1

schedule function war:reset 10s replace
