﻿# Фаза 6 — финал. Плавное сужение 50 -> 1.
# Финал начинается примерно на 15-й минуте, а полный 1-блоковый конец наступает ближе к 17-й минуте.

scoreboard players set #phase phase 6
scoreboard players set #time timer 999999

title @a title {"text":"ФИНАЛЬНАЯ ЗОНА","color":"dark_red","bold":true}
title @a subtitle {"text":"Зона сужается до 1 блока","color":"red"}
tellraw @a {"text":"[WAR] Финальная зона: граница сужается до 1 блока. Урон за зоной сильный, но теперь есть время на реакцию.","color":"dark_red"}
playsound minecraft:entity.ender_dragon.growl master @a ~ ~ ~ 0.9 0.8

