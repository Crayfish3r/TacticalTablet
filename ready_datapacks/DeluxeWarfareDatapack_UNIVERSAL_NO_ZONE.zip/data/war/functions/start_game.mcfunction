# Старт матча.
# Игроки НЕ получают war.playing здесь. Этот тег выдаёт мод только после успешного RTP lobby -> overworld.
scoreboard players set #state gameState 1
scoreboard players set #restart timer 999
scoreboard players set #phase phase 1
ttrespawns enable

gamerule doImmediateRespawn true
gamerule keepInventory false

tag @a remove war.playing
tag @a add in_lobby

title @a title {"text":"GAME START","color":"red","bold":true}
title @a subtitle {"text":"Выберите кит и используйте RTP из лобби","color":"yellow"}
tellraw @a {"text":"[WAR] Игра началась. Зона сбалансирована под 4–8 игроков и будет сужаться примерно 15–20 минут.","color":"green"}
playsound minecraft:entity.ender_dragon.growl master @a ~ ~ ~ 0.7 1
