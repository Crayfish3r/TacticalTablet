# Переключение фаз.
# Центр зоны НЕ меняется, чтобы не было резких скачков worldborder.
# Каждая новая зона строго меньше предыдущей и всегда внутри старой.

scoreboard players add #phase phase 1

execute if score #phase phase matches 2 run function war:p2
execute if score #phase phase matches 3 run function war:p3
execute if score #phase phase matches 4 run function war:p4
execute if score #phase phase matches 5 run function war:p5
execute if score #phase phase matches 6 run function war:p6
