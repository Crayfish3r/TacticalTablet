﻿# Фаза 5. Плавное сужение 110 -> 50.

scoreboard players set #time timer 150
ttrespawns disable

title @a title {"text":"ФАЗА 5","color":"dark_red","bold":true}
title @a subtitle {"text":"Зона плавно сужается до 50 блоков","color":"red"}
tellraw @a {"text":"[WAR] Фаза 5: зона плавно сужается до 50 блоков за 90 секунд. Начинается финальная часть матча.","color":"dark_red"}
playsound minecraft:entity.ender_dragon.growl master @a ~ ~ ~ 0.7 1.1

