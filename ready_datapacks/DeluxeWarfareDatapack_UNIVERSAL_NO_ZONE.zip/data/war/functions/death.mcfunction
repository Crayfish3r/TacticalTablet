# Death/lives logic is controlled by the Forge mod.
# This datapack must not subtract lives or set spectator mode.
