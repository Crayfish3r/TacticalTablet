﻿# Фаза 4. Плавное сужение 180 -> 110.

scoreboard players set #time timer 180

title @a title {"text":"ФАЗА 4","color":"red","bold":true}
title @a subtitle {"text":"Зона плавно сужается до 110 блоков","color":"gold"}
tellraw @a {"text":"[WAR] Фаза 4: зона плавно сужается до 110 блоков за 120 секунд.","color":"red"}
playsound minecraft:block.note_block.bell master @a ~ ~ ~ 1 0.8

