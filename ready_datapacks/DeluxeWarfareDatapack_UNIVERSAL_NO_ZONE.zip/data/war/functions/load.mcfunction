# War Battle Royale — load
# Scoreboard + окружение. Автозапуск контролирует Forge-мод; в тестовом режиме возможен старт с 1 игроком.
# Баланс зоны: 4–8 игроков, целевая длительность матча 15–20 минут.

scoreboard objectives add lives dummy
scoreboard objectives add deaths deathCount
scoreboard objectives add phase dummy
scoreboard objectives add timer dummy
scoreboard objectives add gameState dummy
scoreboard objectives add processedDeath dummy
# Lives are created for Forge-mod display/compatibility only. The Forge mod controls life changes.

execute unless score #state gameState matches 0..1 run scoreboard players set #state gameState 0
execute unless score #phase phase matches 1..6 run scoreboard players set #phase phase 1
execute unless score #time timer matches 0.. run scoreboard players set #time timer 0
execute unless score #restart timer matches 0.. run scoreboard players set #restart timer 15
execute unless score #alive timer matches 0.. run scoreboard players set #alive timer 0
execute unless score #online timer matches 0.. run scoreboard players set #online timer 0

gamerule naturalRegeneration true
gamerule doMobSpawning false
gamerule doWeatherCycle false

schedule clear war:tick
