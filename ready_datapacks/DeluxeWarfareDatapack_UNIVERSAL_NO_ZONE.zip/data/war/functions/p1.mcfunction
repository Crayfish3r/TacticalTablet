﻿# Фаза 1 — подготовка и первые столкновения. Зона 360 блоков в диаметре.
# Центр зоны задаётся в war:start_game через war:random_center.

scoreboard players set #phase phase 1
scoreboard players set #time timer 180

title @a title {"text":"BATTLE ROYALE","color":"gold","bold":true}
title @a subtitle {"text":"Фаза 1: зона 360 блоков","color":"yellow"}
tellraw @a {"text":"[WAR] Фаза 1: стартовая зона 360 блоков. Баланс рассчитан на 4–8 игроков.","color":"gold"}
playsound minecraft:block.note_block.pling master @a ~ ~ ~ 1 1

