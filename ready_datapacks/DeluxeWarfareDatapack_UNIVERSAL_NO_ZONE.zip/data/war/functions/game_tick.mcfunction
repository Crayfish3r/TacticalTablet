# Игровая логика datapack, вызывается 1 раз в секунду, только когда gameState = 1.
# Победителя и систему 3 жизней теперь полностью контролирует Forge-мод,
# чтобы смерть/респавн не конфликтовали с переносом между измерениями.

execute if score #time timer matches 1.. run scoreboard players remove #time timer 1

execute if score #time timer matches 30 unless score #phase phase matches 6 run title @a subtitle {"text":"Новая зона скоро начнёт сужаться","color":"yellow"}
execute if score #time timer matches 10 unless score #phase phase matches 6 run playsound minecraft:block.note_block.pling master @a ~ ~ ~ 0.8 1.4
execute if score #time timer matches ..0 unless score #phase phase matches 6 run function war:next
