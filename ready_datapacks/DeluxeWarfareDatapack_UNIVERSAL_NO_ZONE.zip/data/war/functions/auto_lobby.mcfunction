# Auto-start is controlled by Forge mod GameStateManager.
# This function is intentionally empty to avoid double starts.
