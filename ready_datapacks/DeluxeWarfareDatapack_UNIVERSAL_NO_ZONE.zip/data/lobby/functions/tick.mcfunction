# Scheduled lobby maintenance. Forge handles immediate protection; this is a low-cost safety net.

schedule function lobby:tick 1s replace

execute as @a at @s if dimension lobby:lobby run effect give @s minecraft:resistance 3 255 true
execute as @a at @s if dimension lobby:lobby run effect give @s minecraft:regeneration 3 255 true
execute as @a at @s if dimension lobby:lobby run effect give @s minecraft:saturation 3 1 true
execute as @a at @s if dimension lobby:lobby if entity @s[y=-64,dy=124] run tp @s 0.5 66 0.5
execute as @a[gamemode=spectator] at @s if dimension lobby:lobby run gamemode survival @s
execute in lobby:lobby run kill @e[type=!minecraft:player,type=!minecraft:item,type=!minecraft:marker]

execute as @a[tag=!lobby_title_shown] at @s if dimension lobby:lobby run function lobby:welcome
execute as @a[tag=!lobby_title_shown] at @s if dimension lobby:lobby run tag @s add lobby_title_shown
execute as @a[tag=lobby_title_shown] at @s unless dimension lobby:lobby run tag @s remove lobby_title_shown
