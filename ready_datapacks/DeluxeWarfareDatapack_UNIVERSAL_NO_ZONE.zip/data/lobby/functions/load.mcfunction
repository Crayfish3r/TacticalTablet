﻿# Lobby dimension setup
# Safe isolated waiting area before Battle Royale.

gamerule doMobSpawning false
gamerule doWeatherCycle false
gamerule keepInventory false

execute in lobby:lobby run worldborder center 0 0
execute in lobby:lobby run worldborder set 59999968 1
execute in lobby:lobby run worldborder damage amount 0
execute in lobby:lobby run worldborder warning distance 0
execute in lobby:lobby run worldborder warning time 0
execute in lobby:lobby run weather clear

schedule function lobby:build_spawn 1s replace
schedule function lobby:tick 1s replace
tellraw @a {"text":"[LOBBY] lobby:lobby loaded.","color":"aqua"}

