﻿# Builds the persistent lobby spawn after the custom dimension has finished loading.

execute in lobby:lobby run fill -8 65 -8 8 65 8 minecraft:smooth_stone replace
execute in lobby:lobby run place template lobby:spawn -10 64 -10

