# Показывается игроку один раз при входе в lobby:lobby.
# Текст можно поменять здесь.

title @s times 20 80 20
title @s title {"text":"ДОБРО ПОЖАЛОВАТЬ, ГИТЛЕР","color":"gold","bold":true}
title @s subtitle {"text":"Вы вошли в лобби Battle Royale","color":"yellow"}
playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1
