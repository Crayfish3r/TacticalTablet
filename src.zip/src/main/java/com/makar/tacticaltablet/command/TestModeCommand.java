package com.makar.tacticaltablet.command;

import com.makar.tacticaltablet.admin.TestModeManager;
import com.makar.tacticaltablet.game.GameStateManager;
import com.makar.tacticaltablet.game.MatchMode;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

public class TestModeCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("tttest")
                .requires(source -> source.hasPermission(2))
                .executes(ctx -> sendStatus(ctx.getSource()))
                .then(Commands.literal("solo")
                        .executes(ctx -> sendStatus(ctx.getSource()))
                        .then(Commands.literal("on")
                                .executes(ctx -> setSoloMode(ctx.getSource(), true))
                        )
                        .then(Commands.literal("off")
                                .executes(ctx -> setSoloMode(ctx.getSource(), false))
                        )
                        .then(Commands.literal("toggle")
                                .executes(ctx -> setSoloMode(
                                        ctx.getSource(),
                                        !TestModeManager.isSoloStartEnabled()
                                ))
                        )
                )
                .then(Commands.literal("start")
                        .executes(ctx -> {
                            TestModeManager.setSoloStartEnabled(true);
                            GameStateManager.startGame(ctx.getSource().getServer());
                            ctx.getSource().sendSuccess(
                                    () -> Component.literal("[WAR] Соло-тест включён, матч принудительно запущен."),
                                    true
                            );
                            return 1;
                        })
                )
                .then(Commands.literal("stop")
                        .executes(ctx -> stopMatch(ctx.getSource()))
                )
                .then(Commands.literal("lowplayers")
                        .executes(ctx -> sendStatus(ctx.getSource()))
                        .then(Commands.literal("on")
                                .executes(ctx -> setLowPlayerTeamTests(ctx.getSource(), true))
                        )
                        .then(Commands.literal("off")
                                .executes(ctx -> setLowPlayerTeamTests(ctx.getSource(), false))
                        )
                )
                .then(Commands.literal("vote")
                        .then(Commands.literal("start")
                                .executes(ctx -> startDebugVote(ctx.getSource()))
                        )
                        .then(Commands.literal("stop")
                                .executes(ctx -> stopDebugVote(ctx.getSource()))
                        )
                )
                .then(Commands.literal("teamselect")
                        .then(Commands.literal("duo")
                                .executes(ctx -> startDebugTeamSelect(ctx.getSource(), MatchMode.DUO))
                        )
                        .then(Commands.literal("trio")
                                .executes(ctx -> startDebugTeamSelect(ctx.getSource(), MatchMode.TRIO))
                        )
                        .then(Commands.literal("squads")
                                .executes(ctx -> startDebugTeamSelect(ctx.getSource(), MatchMode.SQUADS))
                        )
                )
        );
    }

    private static int setSoloMode(CommandSourceStack source, boolean enabled) {
        TestModeManager.setSoloStartEnabled(enabled);
        source.sendSuccess(
                () -> Component.literal("[WAR] " + TestModeManager.getStatusText()),
                true
        );
        return enabled ? 1 : 0;
    }

    private static int setLowPlayerTeamTests(CommandSourceStack source, boolean enabled) {
        TestModeManager.setLowPlayerTeamTestsEnabled(enabled);
        source.sendSuccess(
                () -> Component.literal("[WAR] " + TestModeManager.getStatusText()),
                true
        );
        return enabled ? 1 : 0;
    }

    private static int startDebugVote(CommandSourceStack source) {
        TestModeManager.setLowPlayerTeamTestsEnabled(true);
        boolean started = GameStateManager.forceStartVoting(source.getServer());
        source.sendSuccess(
                () -> Component.literal(started
                        ? "[WAR] Отладочное голосование началось. Командные тесты с малым числом игроков включены."
                        : "[WAR] Нельзя запустить отладочное голосование во время матча."),
                true
        );
        return started ? 1 : 0;
    }

    private static int stopDebugVote(CommandSourceStack source) {
        GameStateManager.forceStopMatch(source.getServer());
        TestModeManager.setLowPlayerTeamTestsEnabled(false);
        source.sendSuccess(
                () -> Component.literal("[WAR] Отладочное голосование остановлено. Командные тесты с малым числом игроков выключены."),
                true
        );
        return 1;
    }

    private static int startDebugTeamSelect(CommandSourceStack source, MatchMode mode) {
        TestModeManager.setLowPlayerTeamTestsEnabled(true);
        boolean started = GameStateManager.forceStartTeamSelect(source.getServer(), mode);
        source.sendSuccess(
                () -> Component.literal(started
                        ? "[WAR] Отладочный выбор команды начался: " + mode.displayName()
                        + ". Командные тесты с малым числом игроков включены."
                        : "[WAR] Нельзя запустить отладочный выбор команды во время матча."),
                true
        );
        return started ? 1 : 0;
    }

    private static int stopMatch(CommandSourceStack source) {
        boolean stopped = GameStateManager.forceStopMatch(source.getServer());
        TestModeManager.setLowPlayerTeamTestsEnabled(false);
        source.sendSuccess(
                () -> Component.literal(stopped
                        ? "[WAR] Матч принудительно остановлен. Тестовый режим малого числа игроков выключен."
                        : "[WAR] Состояние матча сброшено. Тестовый режим малого числа игроков выключен."),
                true
        );
        return stopped ? 1 : 0;
    }

    private static int sendStatus(CommandSourceStack source) {
        source.sendSuccess(
                () -> Component.literal("[WAR] " + TestModeManager.getStatusText()),
                false
        );
        return TestModeManager.isSoloStartEnabled() ? 1 : 0;
    }
}
