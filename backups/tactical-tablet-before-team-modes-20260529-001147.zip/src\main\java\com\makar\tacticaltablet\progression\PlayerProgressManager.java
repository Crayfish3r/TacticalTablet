package com.makar.tacticaltablet.progression;

import com.makar.tacticaltablet.core.TacticalTabletMod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Stream;

public class PlayerProgressManager {

    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .disableHtmlEscaping()
            .create();

    private static final String DATA_DIRECTORY = "tacticaltablet_data";
    private static final String PLAYERS_DIRECTORY = "players";
    private static final String BACKUPS_DIRECTORY = "backups";
    private static final String SEASON_FILE = "season.json";

    private static final int DATA_VERSION = 4;
    private static final int EPIC_XP = 300;
    private static final int LEGEND_XP = 800;

    public static final int KILL_COIN_REWARD = 2;
    public static final int WIN_COIN_REWARD = 5;

    private static final String[] STANDARD_CLASSES = new String[]{
            "stormtrooper",
            "sniper",
            "scout",
            "droneoperator",
            "machinegunner",
            "mortarman",
            "rpgtrooper"
    };

    private static final String[] SHOP_CLASSES = new String[]{
            "boomguy",
            "dream",
            "tagilla",
            "blackops"
    };

    private static final String[] ALL_CLASSES = new String[]{
            "stormtrooper",
            "sniper",
            "scout",
            "droneoperator",
            "machinegunner",
            "mortarman",
            "rpgtrooper",
            "boomguy",
            "dream",
            "tagilla",
            "blackops"
    };

    private static final Map<String, Integer> SHOP_CLASS_PRICES = Map.of(
            "boomguy", 200,
            "dream", 100,
            "tagilla", 300,
            "blackops", 500
    );

    private static final Map<String, Integer> SHOP_CLASS_LEVELS = Map.of(
            "boomguy", 2,
            "dream", 1,
            "tagilla", 2,
            "blackops", 2
    );

    private static final int AUTOSAVE_INTERVAL_TICKS = 20 * 60;
    private static final int BACKUP_INTERVAL_TICKS = 20 * 60 * 30;
    private static final int MAX_BACKUP_FOLDERS = 48;

    private static final DateTimeFormatter BACKUP_FORMAT = DateTimeFormatter
            .ofPattern("yyyy-MM-dd_HH-mm-ss")
            .withZone(ZoneId.systemDefault());

    private static final Map<String, PlayerProgress> cache = new HashMap<>();
    private static final Map<String, Boolean> dirty = new HashMap<>();

    private static Path dataRoot;
    private static Path playersRoot;
    private static Path backupsRoot;
    private static int autosaveTicks;
    private static int backupTicks;

    public enum PurchaseResult {
        PURCHASED,
        ALREADY_OWNED,
        NOT_ENOUGH_COINS,
        NOT_PURCHASABLE
    }

    public static String[] getStandardClasses() {
        return STANDARD_CLASSES.clone();
    }

    public static String[] getShopClasses() {
        return SHOP_CLASSES.clone();
    }

    public static String[] getAllClasses() {
        return ALL_CLASSES.clone();
    }

    public static int getShopPrice(String clazz) {
        return SHOP_CLASS_PRICES.getOrDefault(normalizeClass(clazz), 0);
    }

    public static int getShopFixedLevel(String clazz) {
        return SHOP_CLASS_LEVELS.getOrDefault(normalizeClass(clazz), 0);
    }

    public static boolean isShopClass(String clazz) {
        return SHOP_CLASS_PRICES.containsKey(normalizeClass(clazz));
    }

    public static synchronized void loadPlayer(ServerPlayer player) {
        if (player == null) return;

        init(player.server);

        String key = getPlayerKey(player);
        PlayerProgress progress = cache.get(key);
        boolean fileExists = Files.exists(getPlayerFile(key));

        if (progress == null) {
            progress = readOrCreateProgress(player, key);
            cache.put(key, progress);
        }

        boolean changed = updateIdentity(progress, player);
        normalize(progress);

        if (changed || !fileExists) {
            markDirty(key);
            savePlayer(player);
        }
    }

    public static synchronized void savePlayer(ServerPlayer player) {
        if (player == null) return;

        init(player.server);

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);

        updateIdentity(progress, player);
        progress.lastSeen = Instant.now().toEpochMilli();
        normalize(progress);

        try {
            writeJsonAtomically(getPlayerFile(key), progress);
            dirty.remove(key);
        } catch (IOException exception) {
            TacticalTabletMod.LOGGER.error("Failed to save Tactical Tablet progress for {}", key, exception);
        }
    }

    public static synchronized void saveAll() {
        if (playersRoot == null) return;

        for (Map.Entry<String, PlayerProgress> entry : cache.entrySet()) {
            String key = entry.getKey();
            PlayerProgress progress = entry.getValue();

            progress.lastSeen = Instant.now().toEpochMilli();
            normalize(progress);

            try {
                writeJsonAtomically(getPlayerFile(key), progress);
                dirty.remove(key);
            } catch (IOException exception) {
                TacticalTabletMod.LOGGER.error("Failed to save Tactical Tablet progress for {}", key, exception);
            }
        }
    }

    public static synchronized void resetStorage() {
        saveAll();
        cache.clear();
        dirty.clear();
        dataRoot = null;
        playersRoot = null;
        backupsRoot = null;
        autosaveTicks = 0;
        backupTicks = 0;
    }

    public static synchronized int getXP(ServerPlayer player, String clazz) {
        if (player == null || clazz == null) return 0;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));
        return progress.classes.getOrDefault(normalizeClass(clazz), 0);
    }

    public static synchronized void addXP(ServerPlayer player, String clazz, int amount) {
        if (player == null || clazz == null || clazz.isBlank() || amount <= 0) return;

        String normalizedClass = normalizeClass(clazz);
        if (isShopClass(normalizedClass)) return;

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);
        int current = progress.classes.getOrDefault(normalizedClass, 0);

        progress.classes.put(normalizedClass, safeAdd(current, amount));
        markDirty(key);
    }

    public static synchronized void setXP(ServerPlayer player, String clazz, int amount) {
        if (player == null || clazz == null || clazz.isBlank()) return;

        String normalizedClass = normalizeClass(clazz);
        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);
        progress.classes.put(normalizedClass, isShopClass(normalizedClass) ? 0 : Math.max(0, amount));
        markDirty(key);
    }

    public static synchronized int getLevel(ServerPlayer player, String clazz) {
        String normalizedClass = normalizeClass(clazz);

        if (isShopClass(normalizedClass)) {
            return isClassPurchased(player, normalizedClass) ? getShopFixedLevel(normalizedClass) : 0;
        }

        return getLevelForXP(getXP(player, normalizedClass));
    }

    public static int getLevelForXP(int xp) {
        if (xp >= LEGEND_XP) return 2;
        if (xp >= EPIC_XP) return 1;
        return 0;
    }

    public static synchronized void addCoins(ServerPlayer player, int amount) {
        if (player == null || amount == 0) return;

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);
        progress.coins = Math.max(0, safeAdd(progress.coins, amount));
        markDirty(key);
    }

    public static synchronized int getCoins(ServerPlayer player) {
        if (player == null) return 0;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));
        return progress.coins;
    }

    public static synchronized void setCoins(ServerPlayer player, int amount) {
        if (player == null) return;

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);
        progress.coins = Math.max(0, amount);
        markDirty(key);
    }

    public static synchronized void addMatchPlayed(ServerPlayer player) {
        if (player == null) return;

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);
        progress.matchesPlayed = safeAdd(progress.matchesPlayed, 1);
        markDirty(key);
    }

    public static synchronized int getMatchesPlayed(ServerPlayer player) {
        if (player == null) return 0;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));
        return progress.matchesPlayed;
    }

    public static synchronized void addWin(ServerPlayer player) {
        if (player == null) return;

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);
        progress.wins = safeAdd(progress.wins, 1);
        markDirty(key);
    }

    public static synchronized int getWins(ServerPlayer player) {
        if (player == null) return 0;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));
        return progress.wins;
    }

    public static synchronized void addKill(ServerPlayer player) {
        if (player == null) return;

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);
        progress.kills = safeAdd(progress.kills, 1);
        markDirty(key);
    }

    public static synchronized int getKills(ServerPlayer player) {
        if (player == null) return 0;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));
        return progress.kills;
    }

    public static synchronized void addDeath(ServerPlayer player) {
        if (player == null) return;

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);
        progress.deaths = safeAdd(progress.deaths, 1);
        markDirty(key);
    }

    public static synchronized int getDeaths(ServerPlayer player) {
        if (player == null) return 0;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));
        return progress.deaths;
    }

    public static synchronized boolean isClassPurchased(ServerPlayer player, String clazz) {
        if (player == null || clazz == null) return false;

        String normalizedClass = normalizeClass(clazz);
        if (!isShopClass(normalizedClass)) return false;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));
        return progress.purchasedClasses.getOrDefault(normalizedClass, 0) > 0;
    }

    public static synchronized PurchaseResult purchaseClass(ServerPlayer player, String clazz) {
        if (player == null || clazz == null) return PurchaseResult.NOT_PURCHASABLE;

        String normalizedClass = normalizeClass(clazz);
        int price = getShopPrice(normalizedClass);

        if (price <= 0) {
            return PurchaseResult.NOT_PURCHASABLE;
        }

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);

        if (progress.purchasedClasses.getOrDefault(normalizedClass, 0) > 0) {
            return PurchaseResult.ALREADY_OWNED;
        }

        if (progress.coins < price) {
            return PurchaseResult.NOT_ENOUGH_COINS;
        }

        progress.coins -= price;
        progress.purchasedClasses.put(normalizedClass, 1);
        progress.classes.put(normalizedClass, 0);
        markDirty(key);
        return PurchaseResult.PURCHASED;
    }

    public static synchronized Map<String, Integer> getPurchasedClasses(ServerPlayer player) {
        Map<String, Integer> result = new HashMap<>();
        if (player == null) return result;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));

        for (String clazz : SHOP_CLASSES) {
            String normalizedClass = normalizeClass(clazz);
            result.put(normalizedClass, progress.purchasedClasses.getOrDefault(normalizedClass, 0) > 0 ? 1 : 0);
        }

        return result;
    }

    public static synchronized int getCareerProgressPercent(ServerPlayer player) {
        if (player == null) return 0;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));
        double completed = 0.0D;

        for (String clazz : STANDARD_CLASSES) {
            int xp = progress.classes.getOrDefault(normalizeClass(clazz), 0);
            completed += Math.min(Math.max(xp, 0), LEGEND_XP) / (double) LEGEND_XP;
        }

        for (String clazz : SHOP_CLASSES) {
            if (progress.purchasedClasses.getOrDefault(normalizeClass(clazz), 0) > 0) {
                completed += 1.0D;
            }
        }

        int totalGoals = STANDARD_CLASSES.length + SHOP_CLASSES.length;
        if (totalGoals <= 0) return 100;

        return Math.max(0, Math.min(100, (int) Math.round(completed * 100.0D / totalGoals)));
    }

    public static synchronized int getBattlePassXp(ServerPlayer player) {
        if (player == null) return 0;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));
        return progress.battlePassXp;
    }

    public static synchronized void addBattlePassXp(ServerPlayer player, int amount) {
        if (player == null || amount <= 0) return;

        String key = getPlayerKey(player);
        PlayerProgress progress = getOrLoad(player, key);
        progress.battlePassXp = safeAdd(progress.battlePassXp, amount);
        markDirty(key);
    }

    public static synchronized void tick(MinecraftServer server) {
        if (server == null) return;

        init(server);

        autosaveTicks++;
        backupTicks++;

        if (autosaveTicks >= AUTOSAVE_INTERVAL_TICKS) {
            autosaveTicks = 0;
            saveDirty();
        }

        if (backupTicks >= BACKUP_INTERVAL_TICKS) {
            backupTicks = 0;
            backupNow();
        }
    }

    public static synchronized void unloadPlayer(ServerPlayer player) {
        if (player == null) return;

        String key = getPlayerKey(player);
        cache.remove(key);
        dirty.remove(key);
    }

    public static synchronized Map<String, Integer> getAllClassXP(ServerPlayer player) {
        Map<String, Integer> result = new HashMap<>();
        if (player == null) return result;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));

        for (String clazz : ALL_CLASSES) {
            String normalizedClass = normalizeClass(clazz);
            int xp = isShopClass(normalizedClass) ? 0 : progress.classes.getOrDefault(normalizedClass, 0);
            result.put(normalizedClass, xp);
        }

        return result;
    }

    public static synchronized Map<String, Integer> getAllClassLevels(ServerPlayer player) {
        Map<String, Integer> result = new HashMap<>();
        if (player == null) return result;

        PlayerProgress progress = getOrLoad(player, getPlayerKey(player));

        for (String clazz : ALL_CLASSES) {
            String normalizedClass = normalizeClass(clazz);
            int level = isShopClass(normalizedClass) && progress.purchasedClasses.getOrDefault(normalizedClass, 0) > 0
                    ? getShopFixedLevel(normalizedClass)
                    : getLevelForXP(progress.classes.getOrDefault(normalizedClass, 0));
            result.put(normalizedClass, level);
        }

        return result;
    }

    public static synchronized void backupNow() {
        if (playersRoot == null || backupsRoot == null) return;

        saveAll();

        String timestamp = BACKUP_FORMAT.format(Instant.now());
        Path backupRoot = backupsRoot.resolve(timestamp);
        Path backupPlayersRoot = backupRoot.resolve(PLAYERS_DIRECTORY);

        try {
            Files.createDirectories(backupPlayersRoot);
            copyJsonFiles(playersRoot, backupPlayersRoot);

            Path seasonFile = dataRoot.resolve(SEASON_FILE);
            if (Files.exists(seasonFile)) {
                Files.copy(
                        seasonFile,
                        backupRoot.resolve(SEASON_FILE),
                        StandardCopyOption.REPLACE_EXISTING
                );
            }

            cleanOldBackups();
        } catch (IOException exception) {
            TacticalTabletMod.LOGGER.error("Failed to create Tactical Tablet progress backup", exception);
        }
    }

    public static synchronized Path getDataRoot() {
        return dataRoot;
    }

    private static PlayerProgress getOrLoad(ServerPlayer player, String key) {
        init(player.server);

        PlayerProgress cached = cache.get(key);
        if (cached != null) {
            updateIdentity(cached, player);
            return cached;
        }

        PlayerProgress progress = readOrCreateProgress(player, key);
        updateIdentity(progress, player);
        normalize(progress);
        cache.put(key, progress);
        return progress;
    }

    private static PlayerProgress readOrCreateProgress(ServerPlayer player, String key) {
        Path file = getPlayerFile(key);

        if (Files.exists(file)) {
            try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                PlayerProgress progress = GSON.fromJson(reader, PlayerProgress.class);
                return progress == null ? createProgress(player) : progress;
            } catch (JsonSyntaxException | IOException exception) {
                TacticalTabletMod.LOGGER.error("Failed to read Tactical Tablet progress file {}", file, exception);
                backupCorruptFile(file);
            }
        }

        Path legacyFile = getLegacyPlayerFile(player);
        if (legacyFile != null && !legacyFile.equals(file) && Files.exists(legacyFile)) {
            try (Reader reader = Files.newBufferedReader(legacyFile, StandardCharsets.UTF_8)) {
                PlayerProgress progress = GSON.fromJson(reader, PlayerProgress.class);
                TacticalTabletMod.LOGGER.info(
                        "Migrating Tactical Tablet progress for {} from name key {} to UUID key {}",
                        player.getGameProfile().getName(),
                        legacyFile.getFileName(),
                        file.getFileName()
                );
                return progress == null ? createProgress(player) : progress;
            } catch (JsonSyntaxException | IOException exception) {
                TacticalTabletMod.LOGGER.error("Failed to read legacy Tactical Tablet progress file {}", legacyFile, exception);
                backupCorruptFile(legacyFile);
            }
        }

        return createProgress(player);
    }

    private static PlayerProgress createProgress(ServerPlayer player) {
        PlayerProgress progress = new PlayerProgress();
        progress.name = player.getGameProfile().getName();
        progress.uuid = compactUuid(player);
        progress.firstSeen = Instant.now().toEpochMilli();
        progress.lastSeen = progress.firstSeen;
        normalize(progress);
        return progress;
    }

    private static boolean updateIdentity(PlayerProgress progress, ServerPlayer player) {
        boolean changed = false;
        String name = player.getGameProfile().getName();
        String uuid = compactUuid(player);

        if (!Objects.equals(progress.name, name)) {
            progress.name = name;
            changed = true;
        }

        if (!Objects.equals(progress.uuid, uuid)) {
            progress.uuid = uuid;
            changed = true;
        }

        if (progress.firstSeen <= 0L) {
            progress.firstSeen = Instant.now().toEpochMilli();
            changed = true;
        }

        progress.lastSeen = Instant.now().toEpochMilli();
        return changed;
    }

    private static void init(MinecraftServer server) {
        if (server == null || dataRoot != null) return;

        Path worldRoot = server.getWorldPath(LevelResource.ROOT).toAbsolutePath().normalize();
        Path serverRoot = worldRoot.getParent();

        if (serverRoot == null) {
            serverRoot = worldRoot;
        }

        dataRoot = serverRoot.resolve(DATA_DIRECTORY);
        playersRoot = dataRoot.resolve(PLAYERS_DIRECTORY);
        backupsRoot = dataRoot.resolve(BACKUPS_DIRECTORY);

        try {
            Files.createDirectories(playersRoot);
            Files.createDirectories(backupsRoot);
            ensureSeasonFile();
        } catch (IOException exception) {
            TacticalTabletMod.LOGGER.error("Failed to initialize Tactical Tablet progress storage", exception);
        }
    }

    private static void ensureSeasonFile() throws IOException {
        Path seasonFile = dataRoot.resolve(SEASON_FILE);

        if (Files.exists(seasonFile)) return;

        Map<String, Object> season = new HashMap<>();
        season.put("dataVersion", DATA_VERSION);
        season.put("season", 1);
        season.put("createdAt", Instant.now().toString());

        writeJsonAtomically(seasonFile, season);
    }

    private static void saveDirty() {
        if (dirty.isEmpty()) return;

        for (String key : dirty.keySet().toArray(new String[0])) {
            PlayerProgress progress = cache.get(key);
            if (progress == null) {
                dirty.remove(key);
                continue;
            }

            progress.lastSeen = Instant.now().toEpochMilli();
            normalize(progress);

            try {
                writeJsonAtomically(getPlayerFile(key), progress);
                dirty.remove(key);
            } catch (IOException exception) {
                TacticalTabletMod.LOGGER.error("Failed to autosave Tactical Tablet progress for {}", key, exception);
            }
        }
    }

    private static void markDirty(String key) {
        dirty.put(key, Boolean.TRUE);
    }

    private static void normalize(PlayerProgress progress) {
        progress.dataVersion = DATA_VERSION;

        if (progress.name == null) {
            progress.name = "";
        }

        if (progress.uuid == null) {
            progress.uuid = "";
        }

        progress.wins = Math.max(0, progress.wins);
        progress.kills = Math.max(0, progress.kills);
        progress.deaths = Math.max(0, progress.deaths);
        progress.matchesPlayed = Math.max(0, progress.matchesPlayed);
        progress.coins = Math.max(0, progress.coins);
        progress.battlePassXp = Math.max(0, progress.battlePassXp);

        progress.classes = normalizeIntegerMap(progress.classes);
        progress.purchasedClasses = normalizeIntegerMap(progress.purchasedClasses);
        progress.donations = normalizeIntegerMap(progress.donations);
        progress.stats = normalizeIntegerMap(progress.stats);

        for (String clazz : ALL_CLASSES) {
            String normalizedClass = normalizeClass(clazz);
            progress.classes.putIfAbsent(normalizedClass, 0);

            if (isShopClass(normalizedClass)) {
                progress.classes.put(normalizedClass, 0);
            }
        }

        for (String clazz : SHOP_CLASSES) {
            progress.purchasedClasses.putIfAbsent(normalizeClass(clazz), 0);
        }
    }

    private static Map<String, Integer> normalizeIntegerMap(Map<String, Integer> input) {
        Map<String, Integer> result = new HashMap<>();

        if (input == null) {
            return result;
        }

        for (Map.Entry<String, Integer> entry : input.entrySet()) {
            String key = normalizeClass(entry.getKey());
            if (key.isBlank()) continue;

            result.put(key, Math.max(0, entry.getValue() == null ? 0 : entry.getValue()));
        }

        return result;
    }

    private static String normalizeClass(String clazz) {
        return clazz == null ? "" : clazz.trim().toLowerCase(Locale.ROOT);
    }

    private static String getPlayerKey(ServerPlayer player) {
        return compactUuid(player);
    }

    private static Path getLegacyPlayerFile(ServerPlayer player) {
        String legacyKey = getLegacyPlayerKey(player);
        if (legacyKey.isBlank()) return null;

        return getPlayerFile(legacyKey);
    }

    private static String getLegacyPlayerKey(ServerPlayer player) {
        String name = player.getGameProfile().getName();
        String normalized = name == null ? "" : name.trim().toLowerCase(Locale.ROOT);
        normalized = normalized.replaceAll("[^a-z0-9_.-]", "_");

        if (normalized.isBlank()) {
            normalized = compactUuid(player);
        }

        return normalized;
    }

    private static String compactUuid(ServerPlayer player) {
        return player.getUUID().toString().replace("-", "");
    }

    private static Path getPlayerFile(String key) {
        return playersRoot.resolve(key + ".json");
    }

    private static void writeJsonAtomically(Path file, Object value) throws IOException {
        Files.createDirectories(file.getParent());

        Path tempFile = file.resolveSibling(file.getFileName().toString() + ".tmp");

        try (Writer writer = Files.newBufferedWriter(tempFile, StandardCharsets.UTF_8)) {
            GSON.toJson(value, writer);
        }

        try {
            Files.move(
                    tempFile,
                    file,
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE
            );
        } catch (AtomicMoveNotSupportedException exception) {
            Files.move(tempFile, file, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private static void copyJsonFiles(Path sourceRoot, Path targetRoot) throws IOException {
        if (!Files.isDirectory(sourceRoot)) return;

        try (DirectoryStream<Path> stream = Files.newDirectoryStream(sourceRoot, "*.json")) {
            for (Path source : stream) {
                Files.copy(
                        source,
                        targetRoot.resolve(source.getFileName().toString()),
                        StandardCopyOption.REPLACE_EXISTING
                );
            }
        }
    }

    private static void backupCorruptFile(Path file) {
        if (file == null || !Files.exists(file) || backupsRoot == null) return;

        String timestamp = BACKUP_FORMAT.format(Instant.now());
        Path target = backupsRoot.resolve("corrupt_" + timestamp + "_" + file.getFileName());

        try {
            Files.copy(file, target, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException exception) {
            TacticalTabletMod.LOGGER.error("Failed to back up corrupt Tactical Tablet progress file {}", file, exception);
        }
    }

    private static void cleanOldBackups() throws IOException {
        if (!Files.isDirectory(backupsRoot)) return;

        try (Stream<Path> stream = Files.list(backupsRoot)) {
            Path[] backups = stream
                    .filter(Files::isDirectory)
                    .sorted(Comparator.comparing((Path path) -> path.getFileName().toString()).reversed())
                    .toArray(Path[]::new);

            for (int i = MAX_BACKUP_FOLDERS; i < backups.length; i++) {
                deleteRecursively(backups[i]);
            }
        }
    }

    private static void deleteRecursively(Path root) throws IOException {
        if (!Files.exists(root)) return;

        try (Stream<Path> stream = Files.walk(root)) {
            Path[] paths = stream
                    .sorted(Comparator.reverseOrder())
                    .toArray(Path[]::new);

            for (Path path : paths) {
                Files.deleteIfExists(path);
            }
        }
    }

    private static int safeAdd(int current, int amount) {
        if (amount > 0 && current > Integer.MAX_VALUE - amount) {
            return Integer.MAX_VALUE;
        }

        if (amount < 0 && current < Integer.MIN_VALUE - amount) {
            return Integer.MIN_VALUE;
        }

        return current + amount;
    }

    private static final class PlayerProgress {
        private int dataVersion = DATA_VERSION;
        private String name = "";
        private String uuid = "";
        private Map<String, Integer> classes = new HashMap<>();
        private int wins;
        private int kills;
        private int deaths;
        private int matchesPlayed;
        private int coins;
        private int battlePassXp;
        private Map<String, Integer> purchasedClasses = new HashMap<>();
        private Map<String, Integer> donations = new HashMap<>();
        private Map<String, Integer> stats = new HashMap<>();
        private long firstSeen;
        private long lastSeen;
    }
}

