package com.makar.tacticaltablet.game;

import com.makar.tacticaltablet.admin.TestModeManager;
import com.makar.tacticaltablet.airdrop.AirdropManager;
import com.makar.tacticaltablet.core.TacticalTabletMod;
import com.makar.tacticaltablet.game.lives.LivesManager;
import com.makar.tacticaltablet.game.lobby.LobbyManager;
import com.makar.tacticaltablet.game.respawn.RespawnControlManager;
import com.makar.tacticaltablet.game.respawn.RtpTimerManager;
import com.makar.tacticaltablet.game.teleport.SafeTeleport;
import com.makar.tacticaltablet.game.zone.ZoneManager;
import com.makar.tacticaltablet.integration.discord.DiscordLeaderboardService;
import com.makar.tacticaltablet.map.WorldCleanupManager;
import com.makar.tacticaltablet.progression.ClassXPManager;
import com.makar.tacticaltablet.progression.PassiveClassXPManager;
import com.makar.tacticaltablet.progression.PlayerProgressManager;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;

public class GameStateManager {

    public static final ResourceKey<Level> LOBBY_DIMENSION = ResourceKey.create(
            Registries.DIMENSION,
            new ResourceLocation("lobby", "lobby")
    );

    public static final int WAITING = 0;
    public static final int RUNNING = 1;

    private static final int MIN_PLAYERS = 2;
    private static final int START_DELAY_SECONDS = 10;
    private static final int POST_GAME_DELAY_SECONDS = 10;
    private static final int WIN_XP_ALL_CLASSES = 10;
    private static final String GAME_STATE_OBJECTIVE = "gameState";
    private static final ResourceLocation START_GAME_FUNCTION = new ResourceLocation("war", "start_game");
    private static final ResourceLocation RESET_GAME_FUNCTION = new ResourceLocation("war", "reset");

    private static boolean matchHadEnoughPlayers = false;
    private static int matchStartingParticipants = 0;
    private static int tickCounter = 0;
    private static int startCountdown = -1;
    private static int postGameDelay = 0;

    public static int getGameState(MinecraftServer server) {
        if (server == null) return WAITING;

        Objective objective = getOrCreateGameStateObjective(server);
        if (objective == null) return WAITING;

        return server.getScoreboard().getOrCreatePlayerScore("#state", objective).getScore();
    }

    public static void setGameState(MinecraftServer server, int state) {
        if (server == null) return;

        Objective objective = getOrCreateGameStateObjective(server);
        if (objective == null) return;

        Scoreboard scoreboard = server.getScoreboard();
        int current = scoreboard.getOrCreatePlayerScore("#state", objective).getScore();
        if (current != state) {
            scoreboard.getOrCreatePlayerScore("#state", objective).setScore(state);
        }
    }

    private static Objective getOrCreateGameStateObjective(MinecraftServer server) {
        Scoreboard scoreboard = server.getScoreboard();
        Objective objective = scoreboard.getObjective(GAME_STATE_OBJECTIVE);
        if (objective != null) return objective;

        CommandSourceStack source = server.createCommandSourceStack()
                .withSuppressedOutput()
                .withPermission(4);
        server.getCommands().performPrefixedCommand(
                source,
                "scoreboard objectives add " + GAME_STATE_OBJECTIVE + " dummy"
        );

        return scoreboard.getObjective(GAME_STATE_OBJECTIVE);
    }

    public static boolean isRunning(MinecraftServer server) {
        return getGameState(server) == RUNNING;
    }

    public static boolean isInLobby(ServerPlayer player) {
        return player != null && player.level().dimension().equals(LOBBY_DIMENSION);
    }

    public static ServerLevel getLobbyLevel(MinecraftServer server) {
        return server == null ? null : server.getLevel(LOBBY_DIMENSION);
    }

    public static ServerLevel getOverworld(MinecraftServer server) {
        return server == null ? null : server.getLevel(Level.OVERWORLD);
    }

    public static int onlinePlayers(MinecraftServer server) {
        return server == null ? 0 : server.getPlayerList().getPlayerCount();
    }

    public static int playingPlayers(MinecraftServer server) {
        return LivesManager.getAlivePlayerCount(server);
    }

    private static ServerPlayer findWinner(MinecraftServer server) {
        if (server == null) return null;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            if (LivesManager.isAliveParticipant(player)) {
                return player;
            }
        }

        return null;
    }

    public static void onServerTick(MinecraftServer server) {
        if (server == null) return;
        if (++tickCounter < 20) return;
        tickCounter = 0;

        if (postGameDelay > 0) {
            postGameDelay--;
            return;
        }

        if (!isRunning(server)) {
            handleWaitingTick(server);
            return;
        }

        startCountdown = -1;
        ZoneManager.tick(server);
        checkForMatchEnd(server);
    }

    public static void checkForMatchEnd(MinecraftServer server) {
        if (server == null || !isRunning(server) || postGameDelay > 0) return;

        int alive = playingPlayers(server);
        int requiredPlayers = TestModeManager.getRequiredPlayers(MIN_PLAYERS);

        if (requiredPlayers <= 1) {
            return;
        }

        if (alive >= requiredPlayers) {
            matchHadEnoughPlayers = true;
            return;
        }

        if (matchHadEnoughPlayers && alive <= 1) {
            endGame(server, findWinner(server));
        }
    }

    public static void startGame(MinecraftServer server) {
        if (server == null) return;

        if (!validateRuntimeRequirements(server)) {
            setGameState(server, WAITING);
            broadcast(server, "[WAR] Match start cancelled: server setup is incomplete. Check log.");
            return;
        }

        RtpTimerManager.clearAll();
        PassiveClassXPManager.clearAll();
        RespawnControlManager.reset(server);
        LivesManager.resetAll(server);
        setGameState(server, RUNNING);
        AirdropManager.resetAutoScheduler();
        DiscordLeaderboardService.startMatch(server);
        matchHadEnoughPlayers = false;
        matchStartingParticipants = 0;

        CommandSourceStack source = server.createCommandSourceStack().withSuppressedOutput();
        server.getCommands().performPrefixedCommand(source, "function " + START_GAME_FUNCTION);
        ZoneManager.start(server);

        SafeTeleport.preparePool(server);

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            LivesManager.ensureStarted(player);
            PlayerProgressManager.addMatchPlayed(player);
            player.removeTag("war.eliminated");
            player.removeTag("war.playing");
            player.addTag("in_lobby");
            LobbyManager.moveToLobby(player);
            ClassXPManager.sync(player);
        }

        matchStartingParticipants = playingPlayers(server);
        matchHadEnoughPlayers = matchStartingParticipants >= TestModeManager.getRequiredPlayers(MIN_PLAYERS);

        ClassXPManager.syncAll(server);

        broadcast(server, "[WAR] Match started. Choose class and use RTP.");
    }

    public static void endGame(MinecraftServer server) {
        endGame(server, findWinner(server));
    }

    public static void endGame(MinecraftServer server, ServerPlayer winner) {
        if (server == null) return;

        matchHadEnoughPlayers = false;
        matchStartingParticipants = 0;
        startCountdown = -1;
        postGameDelay = POST_GAME_DELAY_SECONDS;

        String winnerName = winner != null ? winner.getName().getString() : "No winner";

        DiscordLeaderboardService.sendCurrentMatchLeaderboard(server, winner);

        if (winner != null) {
            PlayerProgressManager.addWin(winner);
            PlayerProgressManager.addCoins(winner, PlayerProgressManager.WIN_COIN_REWARD);
            ClassXPManager.addXPToAllClasses(winner, WIN_XP_ALL_CLASSES);
            PlayerProgressManager.savePlayer(winner);
        }

        setGameState(server, WAITING);
        AirdropManager.resetAutoScheduler();
        ServerLevel activeAirdropLevel = getOverworld(server);
        if (activeAirdropLevel != null) {
            AirdropManager.cancel(activeAirdropLevel);
        }
        ZoneManager.reset(server);
        RespawnControlManager.reset(server);
        PassiveClassXPManager.clearAll();
        RtpTimerManager.clearAll();
        SafeTeleport.clearPool();

        WorldCleanupManager.clearDroppedItems(server);

        CommandSourceStack source = server.createCommandSourceStack().withSuppressedOutput();
        server.getCommands().performPrefixedCommand(source, "function " + RESET_GAME_FUNCTION);

        LivesManager.resetAll(server);

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.removeTag("war.playing");
            player.removeTag("in_lobby");
            LobbyManager.moveToLobby(player);
            ClassXPManager.sync(player);
        }

        showWinnerTitle(server, winnerName);
    }

    public static void resetRuntime(MinecraftServer server) {
        matchHadEnoughPlayers = false;
        matchStartingParticipants = 0;
        tickCounter = 0;
        startCountdown = -1;
        postGameDelay = 0;

        if (server != null) {
            setGameState(server, WAITING);
        }
    }

    public static boolean validateRuntimeRequirements(MinecraftServer server) {
        if (server == null) return false;

        boolean valid = true;
        if (getOverworld(server) == null) {
            TacticalTabletMod.LOGGER.error("Tactical Tablet setup error: overworld dimension is unavailable.");
            valid = false;
        }
        if (getLobbyLevel(server) == null) {
            TacticalTabletMod.LOGGER.error("Tactical Tablet setup error: lobby:lobby dimension is unavailable.");
            valid = false;
        }
        if (!hasFunction(server, START_GAME_FUNCTION)) {
            TacticalTabletMod.LOGGER.error("Tactical Tablet setup error: datapack function {} is missing.", START_GAME_FUNCTION);
            valid = false;
        }
        if (!hasFunction(server, RESET_GAME_FUNCTION)) {
            TacticalTabletMod.LOGGER.error("Tactical Tablet setup error: datapack function {} is missing.", RESET_GAME_FUNCTION);
            valid = false;
        }

        getOrCreateGameStateObjective(server);
        return valid;
    }

    private static boolean hasFunction(MinecraftServer server, ResourceLocation id) {
        return server.getFunctions().get(id).isPresent();
    }

    private static void handleWaitingTick(MinecraftServer server) {
        matchHadEnoughPlayers = false;

        int requiredPlayers = TestModeManager.getRequiredPlayers(MIN_PLAYERS);

        if (onlinePlayers(server) < requiredPlayers) {
            startCountdown = -1;
            return;
        }

        if (startCountdown < 0) {
            startCountdown = START_DELAY_SECONDS;
            String suffix = TestModeManager.isSoloStartEnabled() ? " (solo test mode)" : "";
            broadcast(server, "[WAR] Match starts in " + startCountdown + " seconds." + suffix);
            return;
        }

        if (startCountdown == 0) {
            startGame(server);
            startCountdown = -1;
            return;
        }

        if (startCountdown <= 5 || startCountdown == START_DELAY_SECONDS) {
            broadcast(server, "[WAR] Match starts in " + startCountdown + "...");
        }

        startCountdown--;
    }

    private static void showWinnerTitle(MinecraftServer server, String winnerName) {
        Component title = Component.literal(winnerName + " WINS!");
        Component subtitle = Component.literal("+10 XP to standard classes, +5 coins");
        Component chat = Component.literal("[WAR] " + winnerName + " wins!");

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 100, 20));
            player.connection.send(new ClientboundSetTitleTextPacket(title));
            player.connection.send(new ClientboundSetSubtitleTextPacket(subtitle));
            player.sendSystemMessage(chat);
        }
    }

    private static void broadcast(MinecraftServer server, String message) {
        Component component = Component.literal(message);

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            player.sendSystemMessage(component);
        }
    }
}

