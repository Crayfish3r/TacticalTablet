package com.makar.tacticaltablet.command;

import com.makar.tacticaltablet.admin.TestModeManager;
import com.makar.tacticaltablet.game.GameStateManager;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

public class TestModeCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("tttest")
                .requires(source -> source.hasPermission(2))
                .executes(ctx -> sendStatus(ctx.getSource()))
                .then(Commands.literal("solo")
                        .executes(ctx -> sendStatus(ctx.getSource()))
                        .then(Commands.literal("on")
                                .executes(ctx -> setSoloMode(ctx.getSource(), true))
                        )
                        .then(Commands.literal("off")
                                .executes(ctx -> setSoloMode(ctx.getSource(), false))
                        )
                        .then(Commands.literal("toggle")
                                .executes(ctx -> setSoloMode(
                                        ctx.getSource(),
                                        !TestModeManager.isSoloStartEnabled()
                                ))
                        )
                )
                .then(Commands.literal("start")
                        .executes(ctx -> {
                            TestModeManager.setSoloStartEnabled(true);
                            GameStateManager.startGame(ctx.getSource().getServer());
                            ctx.getSource().sendSuccess(
                                    () -> Component.literal("[WAR] Solo test mode enabled and match force-started."),
                                    true
                            );
                            return 1;
                        })
                )
        );
    }

    private static int setSoloMode(CommandSourceStack source, boolean enabled) {
        TestModeManager.setSoloStartEnabled(enabled);
        source.sendSuccess(
                () -> Component.literal("[WAR] " + TestModeManager.getStatusText()),
                true
        );
        return enabled ? 1 : 0;
    }

    private static int sendStatus(CommandSourceStack source) {
        source.sendSuccess(
                () -> Component.literal("[WAR] " + TestModeManager.getStatusText()),
                false
        );
        return TestModeManager.isSoloStartEnabled() ? 1 : 0;
    }
}
