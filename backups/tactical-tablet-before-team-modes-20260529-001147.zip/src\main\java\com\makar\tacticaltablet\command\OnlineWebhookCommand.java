package com.makar.tacticaltablet.command;

import com.makar.tacticaltablet.integration.online.OnlineWebhookConfig;
import com.makar.tacticaltablet.integration.online.OnlineWebhookService;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;

public final class OnlineWebhookCommand {

    private OnlineWebhookCommand() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("onlinewebhook")
                .requires(source -> source.hasPermission(2))
                .executes(ctx -> status(ctx.getSource()))
                .then(Commands.literal("status")
                        .executes(ctx -> status(ctx.getSource()))
                )
                .then(Commands.literal("reload")
                        .executes(ctx -> reload(ctx.getSource()))
                )
                .then(Commands.literal("send-now")
                        .executes(ctx -> sendNow(ctx.getSource()))
                )
                .then(Commands.literal("clear-message")
                        .executes(ctx -> clearMessage(ctx.getSource()))
                )
        );
    }

    private static int status(CommandSourceStack source) {
        OnlineWebhookConfig config = OnlineWebhookConfig.get(source.getServer());

        source.sendSuccess(() -> Component.literal("Tactical Tablet online webhook:"), false);
        source.sendSuccess(() -> Component.literal("- enabled: " + config.isEnabled()), false);
        source.sendSuccess(() -> Component.literal("- configured: " + config.hasWebhook()), false);
        source.sendSuccess(() -> Component.literal("- updateIntervalSeconds: " + config.getUpdateIntervalSeconds()), false);
        source.sendSuccess(() -> Component.literal("- restartIntervalMinutes: " + config.getRestartIntervalMinutes()), false);
        source.sendSuccess(() -> Component.literal("- messageId: " + (config.hasMessageId() ? "saved" : "-")), false);

        return config.hasWebhook() ? 1 : 0;
    }

    private static int reload(CommandSourceStack source) {
        OnlineWebhookConfig.reload(source.getServer());
        source.sendSuccess(() -> Component.literal("Online webhook config reloaded."), true);
        return 1;
    }

    private static int sendNow(CommandSourceStack source) {
        boolean queued = OnlineWebhookService.sendUpdateNow(source.getServer());

        if (!queued) {
            source.sendFailure(Component.literal("Online webhook is disabled, not configured, or already busy."));
            return 0;
        }

        source.sendSuccess(() -> Component.literal("Online webhook update queued."), true);
        return 1;
    }

    private static int clearMessage(CommandSourceStack source) {
        OnlineWebhookConfig.clearMessageId();
        source.sendSuccess(() -> Component.literal("Online webhook message id cleared. The next update will create a new Discord message."), true);
        return 1;
    }
}

