package com.makar.tacticaltablet.tablet.net;

import com.makar.tacticaltablet.tablet.client.TabletClientState;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

public class TabletStatePacket {

    private static final int MAX_COOLDOWNS = 32;
    private static final int MAX_CLASS_ENTRIES = 64;
    private static final int MAX_CLASS_KEY_LENGTH = 64;

    private final Map<Integer, Long> cooldowns;
    private final boolean kitUsed;
    private final boolean rtpUsed;
    private final long rtpEndTime;
    private final Map<String, Integer> classLevels;
    private final Map<String, Integer> classXP;
    private final Map<String, Integer> purchasedClasses;
    private final boolean gameRunning;
    private final int wins;
    private final int kills;
    private final int deaths;
    private final int matchesPlayed;
    private final int coins;
    private final int careerProgressPercent;
    private final int lives;
    private final int alivePlayers;
    private final int remainingLivesTotal;
    private final int tabletAppearanceTier;

    public TabletStatePacket(
            Map<Integer, Long> cooldowns,
            boolean kitUsed,
            boolean rtpUsed,
            long rtpEndTime,
            Map<String, Integer> classLevels,
            Map<String, Integer> classXP,
            Map<String, Integer> purchasedClasses,
            boolean gameRunning,
            int wins,
            int kills,
            int deaths,
            int matchesPlayed,
            int coins,
            int careerProgressPercent,
            int lives,
            int alivePlayers,
            int remainingLivesTotal,
            int tabletAppearanceTier
    ) {
        this.cooldowns = copyIntLongMap(cooldowns, MAX_COOLDOWNS);
        this.kitUsed = kitUsed;
        this.rtpUsed = rtpUsed;
        this.rtpEndTime = rtpEndTime;
        this.classLevels = copyStringIntMap(classLevels, MAX_CLASS_ENTRIES);
        this.classXP = copyStringIntMap(classXP, MAX_CLASS_ENTRIES);
        this.purchasedClasses = copyStringIntMap(purchasedClasses, MAX_CLASS_ENTRIES);
        this.gameRunning = gameRunning;
        this.wins = wins;
        this.kills = kills;
        this.deaths = deaths;
        this.matchesPlayed = matchesPlayed;
        this.coins = coins;
        this.careerProgressPercent = careerProgressPercent;
        this.lives = Math.max(0, lives);
        this.alivePlayers = Math.max(0, alivePlayers);
        this.remainingLivesTotal = Math.max(0, remainingLivesTotal);
        this.tabletAppearanceTier = Math.max(0, tabletAppearanceTier);
    }

    public TabletStatePacket(
            Map<Integer, Long> cooldowns,
            boolean kitUsed,
            boolean rtpUsed,
            long rtpEndTime,
            Map<String, Integer> classLevels,
            Map<String, Integer> classXP,
            boolean gameRunning
    ) {
        this(
                cooldowns,
                kitUsed,
                rtpUsed,
                rtpEndTime,
                classLevels,
                classXP,
                new HashMap<>(),
                gameRunning,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0
        );
    }

    public TabletStatePacket(FriendlyByteBuf buf) {
        this.cooldowns = new HashMap<>();

        int cdSize = readBoundedSize(buf, MAX_COOLDOWNS, "cooldowns");
        for (int i = 0; i < cdSize; i++) {
            cooldowns.put(buf.readInt(), buf.readLong());
        }

        this.kitUsed = buf.readBoolean();
        this.rtpUsed = buf.readBoolean();
        this.rtpEndTime = buf.readLong();

        this.classLevels = new HashMap<>();
        int levelSize = readBoundedSize(buf, MAX_CLASS_ENTRIES, "classLevels");
        for (int i = 0; i < levelSize; i++) {
            classLevels.put(buf.readUtf(MAX_CLASS_KEY_LENGTH), buf.readInt());
        }

        this.classXP = new HashMap<>();
        int xpSize = readBoundedSize(buf, MAX_CLASS_ENTRIES, "classXP");
        for (int i = 0; i < xpSize; i++) {
            classXP.put(buf.readUtf(MAX_CLASS_KEY_LENGTH), buf.readInt());
        }

        this.purchasedClasses = new HashMap<>();
        int purchasedSize = readBoundedSize(buf, MAX_CLASS_ENTRIES, "purchasedClasses");
        for (int i = 0; i < purchasedSize; i++) {
            purchasedClasses.put(buf.readUtf(MAX_CLASS_KEY_LENGTH), buf.readInt());
        }

        this.gameRunning = buf.readBoolean();
        this.wins = buf.readInt();
        this.kills = buf.readInt();
        this.deaths = buf.readInt();
        this.matchesPlayed = buf.readInt();
        this.coins = buf.readInt();
        this.careerProgressPercent = buf.readInt();
        this.lives = buf.readInt();
        this.alivePlayers = buf.readInt();
        this.remainingLivesTotal = buf.readInt();
        this.tabletAppearanceTier = buf.readInt();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(cooldowns.size());
        for (var entry : cooldowns.entrySet()) {
            buf.writeInt(entry.getKey());
            buf.writeLong(entry.getValue());
        }

        buf.writeBoolean(kitUsed);
        buf.writeBoolean(rtpUsed);
        buf.writeLong(rtpEndTime);

        buf.writeInt(classLevels.size());
        for (var entry : classLevels.entrySet()) {
            buf.writeUtf(entry.getKey());
            buf.writeInt(entry.getValue());
        }

        buf.writeInt(classXP.size());
        for (var entry : classXP.entrySet()) {
            buf.writeUtf(entry.getKey());
            buf.writeInt(entry.getValue());
        }

        buf.writeInt(purchasedClasses.size());
        for (var entry : purchasedClasses.entrySet()) {
            buf.writeUtf(entry.getKey());
            buf.writeInt(entry.getValue());
        }

        buf.writeBoolean(gameRunning);
        buf.writeInt(wins);
        buf.writeInt(kills);
        buf.writeInt(deaths);
        buf.writeInt(matchesPlayed);
        buf.writeInt(coins);
        buf.writeInt(careerProgressPercent);
        buf.writeInt(lives);
        buf.writeInt(alivePlayers);
        buf.writeInt(remainingLivesTotal);
        buf.writeInt(tabletAppearanceTier);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            TabletClientState.update(cooldowns, kitUsed, rtpUsed, rtpEndTime);
            TabletClientState.updateLevels(classLevels);
            TabletClientState.updateXP(classXP);
            TabletClientState.updatePurchasedClasses(purchasedClasses);
            TabletClientState.updateGameRunning(gameRunning);
            TabletClientState.updateProfileStats(wins, kills, deaths, matchesPlayed, coins, careerProgressPercent);
            TabletClientState.updateLives(lives);
            TabletClientState.updateMatchCounts(alivePlayers, remainingLivesTotal);
            TabletClientState.updateTabletAppearanceTier(tabletAppearanceTier);

            if (kitUsed && rtpUsed) {
                TabletClientState.requestClose();
            }
        });
        ctx.get().setPacketHandled(true);
    }

    private static int readBoundedSize(FriendlyByteBuf buf, int max, String field) {
        int size = buf.readInt();
        if (size < 0 || size > max) {
            throw new IllegalArgumentException("Invalid " + field + " size: " + size + " max=" + max);
        }
        return size;
    }

    private static Map<Integer, Long> copyIntLongMap(Map<Integer, Long> input, int maxEntries) {
        Map<Integer, Long> result = new HashMap<>();
        if (input == null || input.isEmpty()) return result;

        for (var entry : input.entrySet()) {
            if (result.size() >= maxEntries) break;
            if (entry.getKey() == null || entry.getValue() == null) continue;
            result.put(entry.getKey(), entry.getValue());
        }
        return result;
    }

    private static Map<String, Integer> copyStringIntMap(Map<String, Integer> input, int maxEntries) {
        Map<String, Integer> result = new HashMap<>();
        if (input == null || input.isEmpty()) return result;

        for (var entry : input.entrySet()) {
            if (result.size() >= maxEntries) break;
            if (entry.getKey() == null || entry.getValue() == null) continue;

            String key = entry.getKey();
            if (key.length() > MAX_CLASS_KEY_LENGTH) {
                key = key.substring(0, MAX_CLASS_KEY_LENGTH);
            }
            result.put(key, entry.getValue());
        }
        return result;
    }
}

