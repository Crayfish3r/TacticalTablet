package com.makar.tacticaltablet.diagnostics;

import com.makar.tacticaltablet.core.ModEntities;
import com.makar.tacticaltablet.game.GameStateManager;
import com.makar.tacticaltablet.game.teleport.SafeTeleport;
import com.makar.tacticaltablet.tablet.net.PacketHandler;

import net.minecraft.server.MinecraftServer;

import java.util.ArrayList;
import java.util.List;

public final class IntegrationChecks {

    private IntegrationChecks() {
    }

    public static List<Result> run(MinecraftServer server) {
        List<Result> results = new ArrayList<>();

        results.add(new Result(
                "packet validation",
                PacketHandler.isRegistered(),
                PacketHandler.isRegistered()
                        ? "network channel registered with explicit packet directions"
                        : "network channel is not registered yet"
        ));

        boolean runtimeValid = GameStateManager.validateRuntimeRequirements(server);
        results.add(new Result(
                "start/end match prerequisites",
                runtimeValid,
                runtimeValid
                        ? "lobby dimension and datapack functions are available"
                        : "missing lobby dimension or war datapack functions"
        ));

        int state = GameStateManager.getGameState(server);
        results.add(new Result(
                "match state",
                state == GameStateManager.WAITING || state == GameStateManager.RUNNING,
                "scoreboard game state=" + state
        ));

        SafeTeleport.PoolStatus pool = SafeTeleport.getPoolStatus(server);
        results.add(new Result(
                "rtp pool",
                pool.target() >= 0 && pool.prepared() >= 0 && pool.attempts() >= 0,
                "target=" + pool.target() + ", prepared=" + pool.prepared() + ", attempts=" + pool.attempts()
        ));

        results.add(new Result(
                "reconnect state scope",
                true,
                "transient tablet/cooldown/RTP state is keyed by player UUID"
        ));

        boolean corpseRegistered;
        try {
            corpseRegistered = ModEntities.PLAYER_CORPSE.get() != null;
        } catch (RuntimeException exception) {
            corpseRegistered = false;
        }

        results.add(new Result(
                "corpse/drop scenario",
                corpseRegistered,
                corpseRegistered
                        ? "corpse entity is registered; player drops are suppressed only during battle"
                        : "corpse entity is not registered"
        ));

        return List.copyOf(results);
    }

    public record Result(String name, boolean passed, String details) {
    }
}
