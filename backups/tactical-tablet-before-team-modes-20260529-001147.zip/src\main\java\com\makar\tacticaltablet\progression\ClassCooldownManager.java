package com.makar.tacticaltablet.progression;

import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

public class ClassCooldownManager {

    private static final long[] COOLDOWNS = new long[]{
            minutes(7),
            minutes(10),
            minutes(10),
            minutes(15),
            minutes(13),
            minutes(6),
            minutes(15),
            0L,
            minutes(10),
            minutes(13),
            minutes(15),
            minutes(15)
    };

    private static final Map<UUID, Map<Integer, Long>> data = new HashMap<>();

    private static long getCooldownTime(int classId) {
        if (classId < 0 || classId >= COOLDOWNS.length) {
            return 0L;
        }

        return COOLDOWNS[classId];
    }

    private static long minutes(int minutes) {
        return minutes * 60L * 1000L;
    }

    public static void setCooldown(ServerPlayer player, int classId) {
        if (player == null || classId < 0 || classId >= COOLDOWNS.length) return;

        data.computeIfAbsent(player.getUUID(), key -> new HashMap<>())
                .put(classId, System.currentTimeMillis());
    }

    public static long getRemaining(ServerPlayer player, int classId) {
        if (player == null || classId < 0 || classId >= COOLDOWNS.length) return 0L;

        Map<Integer, Long> map = data.get(player.getUUID());
        if (map == null) return 0L;

        Long start = map.get(classId);
        if (start == null) return 0L;

        long left = getCooldownTime(classId) - (System.currentTimeMillis() - start);
        if (left <= 0L) {
            map.remove(classId);
            if (map.isEmpty()) {
                data.remove(player.getUUID());
            }

            return 0L;
        }

        return left;
    }

    public static boolean isOnCooldown(ServerPlayer player, int classId) {
        return getRemaining(player, classId) > 0L;
    }

    public static Map<Integer, Long> getCooldowns(ServerPlayer player) {
        Map<Integer, Long> result = new HashMap<>();
        if (player == null) return result;

        Map<Integer, Long> map = data.get(player.getUUID());
        if (map == null || map.isEmpty()) return result;

        long now = System.currentTimeMillis();
        Iterator<Map.Entry<Integer, Long>> iterator = map.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<Integer, Long> entry = iterator.next();
            int classId = entry.getKey();
            long left = getCooldownTime(classId) - (now - entry.getValue());

            if (left <= 0L) {
                iterator.remove();
                continue;
            }

            result.put(classId, left);
        }

        if (map.isEmpty()) {
            data.remove(player.getUUID());
        }

        return result;
    }

    public static void reset(ServerPlayer player) {
        if (player == null) return;
        data.remove(player.getUUID());
    }

    public static void resetAll() {
        data.clear();
    }
}

