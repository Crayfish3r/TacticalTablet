package com.makar.tacticaltablet.tablet.net;

import com.makar.tacticaltablet.anticheat.AntiCheatManager;
import com.makar.tacticaltablet.anticheat.Severity;
import com.makar.tacticaltablet.anticheat.ViolationType;
import com.makar.tacticaltablet.game.GameStateManager;
import com.makar.tacticaltablet.game.lives.LivesManager;
import com.makar.tacticaltablet.game.lobby.LobbyManager;
import com.makar.tacticaltablet.game.respawn.RtpTimerManager;
import com.makar.tacticaltablet.inventory.InventoryManager;
import com.makar.tacticaltablet.progression.ClassCooldownManager;
import com.makar.tacticaltablet.progression.kit.KitManager;
import com.makar.tacticaltablet.progression.PlayerProgressManager;
import com.makar.tacticaltablet.tablet.PlayerTabletState;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Supplier;

public class TabletPacket {

    private static final int RTP_ACTION_ID = 7;
    private static final int MIN_ACTION_ID = 0;
    private static final int MAX_ACTION_ID = 11;
    private static final int MAX_TABLET_ACTIONS = 3;
    private static final long TABLET_RATE_WINDOW_MS = 2_000L;
    private static final Map<UUID, Deque<Long>> tabletActionTimes = new HashMap<>();

    private static final Map<Integer, String> KITS = Map.ofEntries(
            Map.entry(0, "stormtrooper"),
            Map.entry(1, "sniper"),
            Map.entry(2, "scout"),
            Map.entry(3, "droneoperator"),
            Map.entry(4, "boomguy"),
            Map.entry(5, "mortarman"),
            Map.entry(6, "dream"),
            Map.entry(8, "machinegunner"),
            Map.entry(9, "rpgtrooper"),
            Map.entry(10, "tagilla"),
            Map.entry(11, "blackops")
    );

    private final int actionId;

    public TabletPacket(int actionId) {
        this.actionId = actionId;
    }

    public TabletPacket(FriendlyByteBuf buf) {
        int decodedActionId = buf.readInt();
        if (decodedActionId < MIN_ACTION_ID || decodedActionId > MAX_ACTION_ID) {
            throw new IllegalArgumentException("Invalid tablet actionId: " + decodedActionId);
        }
        this.actionId = decodedActionId;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(actionId);
    }

    public static void reset(ServerPlayer player) {
        if (player == null) return;
        tabletActionTimes.remove(player.getUUID());
    }

    public static void resetAll() {
        tabletActionTimes.clear();
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;

            if (!allowTabletAction(player)) {
                AntiCheatManager.record(
                        player,
                        ViolationType.PACKET_SPAM,
                        Severity.HIGH,
                        "tablet packet rate exceeded actionId=" + actionId
                );
                return;
            }

            if (!InventoryManager.hasTablet(player)) {
                AntiCheatManager.record(
                        player,
                        ViolationType.INVALID_TABLET_PACKET,
                        Severity.HIGH,
                        "tablet packet without tablet actionId=" + actionId
                );
                LobbyManager.sync(player);
                return;
            }

            if (actionId == RTP_ACTION_ID) {
                handleRtp(player);
                return;
            }

            String kit = KITS.get(actionId);
            if (kit == null) {
                AntiCheatManager.record(
                        player,
                        ViolationType.INVALID_TABLET_PACKET,
                        Severity.HIGH,
                        "unknown actionId=" + actionId
                );
                return;
            }

            if (PlayerProgressManager.isShopClass(kit) && !PlayerProgressManager.isClassPurchased(player, kit)) {
                handleShopPurchase(player, kit);
                return;
            }

            handleKit(player, kit);
        });

        ctx.get().setPacketHandled(true);
    }

    private boolean allowTabletAction(ServerPlayer player) {
        long now = System.currentTimeMillis();
        Deque<Long> timestamps = tabletActionTimes.computeIfAbsent(player.getUUID(), uuid -> new ArrayDeque<>());

        while (!timestamps.isEmpty() && now - timestamps.peekFirst() > TABLET_RATE_WINDOW_MS) {
            timestamps.removeFirst();
        }

        if (timestamps.size() >= MAX_TABLET_ACTIONS) {
            return false;
        }

        timestamps.addLast(now);
        return true;
    }

    private void handleShopPurchase(ServerPlayer player, String kit) {
        PlayerProgressManager.PurchaseResult result = PlayerProgressManager.purchaseClass(player, kit);

        switch (result) {
            case PURCHASED -> {
                player.sendSystemMessage(Component.literal("[WAR] Purchased " + getDisplayName(kit)
                        + " for " + PlayerProgressManager.getShopPrice(kit) + " coins."));
                PlayerProgressManager.savePlayer(player);
            }
            case ALREADY_OWNED -> player.sendSystemMessage(Component.literal("[WAR] You already own " + getDisplayName(kit) + "."));
            case NOT_ENOUGH_COINS -> player.sendSystemMessage(Component.literal("[WAR] Not enough coins for " + getDisplayName(kit)
                    + ". Need " + PlayerProgressManager.getShopPrice(kit) + " coins."));
            case NOT_PURCHASABLE -> player.sendSystemMessage(Component.literal("[WAR] This class cannot be purchased."));
        }

        LobbyManager.sync(player);
    }

    private void handleRtp(ServerPlayer player) {
        String invalidReason = getInvalidRtpReason(player);
        if (!invalidReason.isEmpty()) {
            AntiCheatManager.record(
                    player,
                    ViolationType.INVALID_RTP,
                    getInvalidRtpSeverity(invalidReason),
                    invalidReason
            );
        }

        if (!GameStateManager.isRunning(player.server)) {
            player.sendSystemMessage(Component.literal("[WAR] Tablet is disabled until the match starts."));
            LobbyManager.sync(player);
            return;
        }

        RtpTimerManager.forceRtp(player);
    }

    private String getInvalidRtpReason(ServerPlayer player) {
        if (!GameStateManager.isRunning(player.server)) {
            return "game not running";
        }

        if (!LivesManager.canContinueMatch(player)) {
            return "player eliminated";
        }

        if (!GameStateManager.isInLobby(player)) {
            return "not in lobby dimension";
        }

        if (!player.getTags().contains("in_lobby")) {
            return "missing in_lobby tag";
        }

        if (PlayerTabletState.isRtpUsed(player)) {
            return "rtp already used";
        }

        return "";
    }

    private Severity getInvalidRtpSeverity(String reason) {
        if ("not in lobby dimension".equals(reason)
                || "missing in_lobby tag".equals(reason)
                || "rtp already used".equals(reason)) {
            return Severity.HIGH;
        }

        return Severity.MEDIUM;
    }

    private void handleKit(ServerPlayer player, String kit) {
        if (PlayerProgressManager.isShopClass(kit) && !PlayerProgressManager.isClassPurchased(player, kit)) {
            handleShopPurchase(player, kit);
            return;
        }

        if (!GameStateManager.isRunning(player.server)) {
            player.sendSystemMessage(Component.literal("[WAR] Tablet is disabled until the match starts."));
            LobbyManager.sync(player);
            return;
        }

        boolean inLobby = player.getTags().contains("in_lobby") || GameStateManager.isInLobby(player);
        boolean inBattle = player.getTags().contains("war.playing");

        if (!inLobby && !inBattle) {
            player.sendSystemMessage(Component.literal("[WAR] Class selection is not available now."));
            LobbyManager.sync(player);
            return;
        }

        if (!LivesManager.canContinueMatch(player)) {
            player.sendSystemMessage(Component.literal("[WAR] You are eliminated."));
            LobbyManager.sync(player);
            return;
        }

        if (PlayerTabletState.isKitUsed(player)) {
            LobbyManager.sync(player);
            return;
        }

        if (ClassCooldownManager.isOnCooldown(player, actionId)) {
            LobbyManager.sync(player);
            return;
        }

        if (!KitManager.giveKit(player, kit)) {
            player.sendSystemMessage(Component.literal("[WAR] Kit failed to load. Try another class or check server kit config."));
            LobbyManager.sync(player);
            return;
        }

        PlayerTabletState.setSelectedClass(player, kit);
        ClassCooldownManager.setCooldown(player, actionId);
        PlayerTabletState.setKitUsed(player);

        if (PlayerTabletState.isRtpUsed(player)) {
            InventoryManager.clearTablets(player);
        }

        LobbyManager.sync(player);
    }

    private String getDisplayName(String kit) {
        if ("boomguy".equals(kit)) return "Boomguy";
        if ("dream".equals(kit)) return "Dream";
        if ("rpgtrooper".equals(kit)) return "RPG Trooper";
        if ("tagilla".equals(kit)) return "Tagilla";
        if ("blackops".equals(kit)) return "Black OPS";
        return kit;
    }
}

