package com.makar.tacticaltablet.admin;

import com.makar.tacticaltablet.game.GameStateManager;

import net.minecraft.server.MinecraftServer;

public class TestModeManager {

    private static boolean soloStartEnabled = false;

    public static boolean isSoloStartEnabled() {
        return soloStartEnabled;
    }

    public static void setSoloStartEnabled(boolean enabled) {
        soloStartEnabled = enabled;
    }

    public static void reset() {
        soloStartEnabled = false;
    }

    public static int getRequiredPlayers(int defaultMinimum) {
        return soloStartEnabled ? 1 : defaultMinimum;
    }

    public static boolean hasEnoughOnlinePlayers(MinecraftServer server, int defaultMinimum) {
        return GameStateManager.onlinePlayers(server) >= getRequiredPlayers(defaultMinimum);
    }

    public static String getStatusText() {
        return soloStartEnabled
                ? "solo test mode is ON. Matches can start with 1 player."
                : "solo test mode is OFF. Matches require normal player count.";
    }
}

